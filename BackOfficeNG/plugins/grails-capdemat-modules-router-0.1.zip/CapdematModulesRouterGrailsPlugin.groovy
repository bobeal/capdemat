import java.io.File;
import helpers.*;
//import com.zenexity.capdemat.utils.*


class CapdematModulesRouterGrailsPlugin {
    def version = 0.1
    def dependsOn = [:];
    def author = 'Victor Bartel'
    def authorEmail = 'vba@zenexity.fr'
            
    def watchedResources = [
        "file:./modules/**/*Controller.groovy",
        "file:./modules/**/*.gsp"
    ];
    
    def doWithWebDescriptor = { xml ->
        println '# MODULES ROUTER PREPARE ALL #'
        def basedir = new File('.').canonicalPath
        ModuleHelper.prepareAll(basedir)
    }
    
    def onChange = { event ->
        def basedir = new File(event?.ctx.servletContext.getRealPath('.')).parent
        println "# MODULES ROUTER modified file : ${event.source.file.canonicalPath}"
        if(event?.source?.file) ModuleHelper.prepare(event.source.file,basedir)
    }
    
}