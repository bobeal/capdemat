import helpers.*;
import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU
import groovy.text.SimpleTemplateEngine

Ant.property(environment:"env")
grailsHome = Ant.antProject.properties."env.GRAILS_HOME"
includeTargets << new File ( "${grailsHome}/scripts/Compile.groovy" )

target ('default': "Prepare all project modules") {
    prepareMod();
    compile();
}

target (prepareMod: "Implementation of prepare-mod") {
    //depends(compile);
    event("PrepareModStart", [])
    println "# MODULES ROUTER PREPARE ALL #"
    ModuleHelper.prepareAll(basedir);
    
//    try {ModuleHelper.prepareAll(basedir);}
//    catch(Exception e){println "# MODULES ROUTER WARNING ModuleHelper class not found"}
    event("PrepareModEnd", [])
}