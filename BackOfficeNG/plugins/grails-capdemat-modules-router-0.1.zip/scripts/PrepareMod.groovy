import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU
import groovy.text.SimpleTemplateEngine

ant.property(environment:"env")

includeTargets << grailsScript( "_GrailsCompile" )

target ('default': "Prepare all project modules") {
    prepareMod();
    //compile();
}

target (prepareMod: "Implementation of prepare-mod") {
    //depends(compile);
    event("PrepareModStart", [])
    println "# MODULES ROUTER PREPARE ALL #"
    ModuleHelper.prepareAll(basedir);
    
//    try {ModuleHelper.prepareAll(basedir);}
//    catch(Exception e){println "# MODULES ROUTER WARNING ModuleHelper class not found"}
    event("PrepareModEnd", [])
}
