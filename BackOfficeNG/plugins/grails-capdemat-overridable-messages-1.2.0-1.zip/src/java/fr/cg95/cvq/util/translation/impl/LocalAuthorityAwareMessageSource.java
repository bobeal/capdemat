package fr.cg95.cvq.util.translation.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.codehaus.groovy.grails.context.support.PluginAwareResourceBundleMessageSource;
import org.codehaus.groovy.grails.plugins.GrailsPluginManager;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.util.StringUtils;

import fr.cg95.cvq.security.SecurityContext;
import fr.cg95.cvq.service.authority.impl.LocalAuthorityRegistry;

public class LocalAuthorityAwareMessageSource implements MessageSource, ResourceLoaderAware {

    private LocalAuthorityRegistry localAuthorityRegistry;

    private PathMatchingResourcePatternResolver resolver;

    private PluginAwareResourceBundleMessageSource common;

    public LocalAuthorityAwareMessageSource(String[] basenames, GrailsPluginManager manager,
        boolean reloadEnabled) {
        common = new PluginAwareResourceBundleMessageSource();
        common.setBasenames(basenames);
        common.setPluginManager(manager);
        if (reloadEnabled) common.setCacheSeconds(5);
        common.setFallbackToSystemLocale(false);
    }

    private MessageSource getCustom() {
        List<String> basenames = new ArrayList<String>();
        if (SecurityContext.getCurrentSite() != null) {
            try {
                for (Resource file : resolver.getResources("file:"
                    + localAuthorityRegistry.getAssetsBase()
                    + SecurityContext.getCurrentSite().getName().toLowerCase()
                    + "/i18n/*.properties")) {
                    basenames.add(StringUtils.stripFilenameExtension(file.getURL().toString()));
                }
            } catch (IOException e) {
                // Any problem loading specific i18n files ?
                // Nevermind, let's leave custom source empty, it will fallback on the common one
            }
        }
        ReloadableResourceBundleMessageSource custom = new ReloadableResourceBundleMessageSource();
        custom.setBasenames(basenames.toArray(new String[basenames.size()]));
        custom.setDefaultEncoding("UTF-8");
        custom.setFallbackToSystemLocale(false);
        return custom;
    }

    @Override
    public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
        try {
            return getCustom().getMessage(code, args, locale);
        } catch (NoSuchMessageException e) {
            return common.getMessage(code, args, defaultMessage, locale);
        }
    }

    @Override
    public String getMessage(String code, Object[] args, Locale locale)
        throws NoSuchMessageException {
        try {
            return getCustom().getMessage(code, args, locale);
        } catch (NoSuchMessageException e) {
            return common.getMessage(code, args, locale);
        }
    }

    @Override
    public String getMessage(MessageSourceResolvable resolvable, Locale locale)
        throws NoSuchMessageException {
        try {
            return getCustom().getMessage(resolvable, locale);
        } catch (NoSuchMessageException e) {
            return common.getMessage(resolvable, locale);
        }
    }

    public void clearCache() {
        common.clearCache();
    }

    public void setLocalAuthorityRegistry(LocalAuthorityRegistry localAuthorityRegistry) {
        this.localAuthorityRegistry = localAuthorityRegistry;
    }

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        common.setResourceLoader(resourceLoader);
        resolver = new PathMatchingResourcePatternResolver(resourceLoader);
    }
}
