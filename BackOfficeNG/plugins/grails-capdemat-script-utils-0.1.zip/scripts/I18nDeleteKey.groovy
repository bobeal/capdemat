target ('default': "Delete a key from all known keys files") {
    deleteKey()
}

target (deleteKey: "Delete a key from all known keys files") {
    def args = System.getProperty("grails.cli.args")
    if (!args) {
        println "This script requires a 'key' argument"
        System.exit(-1)
    }
    
    def keyToRemove = args.trim()
    println "Gonna remove key ${keyToRemove}"
    
    I18nSupport.forEachLangFile({ file ->
        def outputFile = new File(file.absolutePath + '.output')
        def outputWriter = outputFile.newWriter()
        def writable = file.filterLine() { !it.startsWith(keyToRemove) }
        writable.writeTo(outputWriter)
        outputFile.renameTo(file)
    })
}
