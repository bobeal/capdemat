
target ('default': "Check keys in properties files and print out unused ones") {
    findMissingKeys()
}

target (findMissingKeys: "Check keys in properties files and print out unused ones") {

    def referenceKeys = I18nSupport.extractKeys()

    I18nSupport.eachKeysInLangFile({ lang, langKeys ->
        println "analyzing keys for ${lang} ..."
        langKeys.each {
            if (!referenceKeys.contains(it))
                println "$it in $lang does not exist in reference file"
        }
        referenceKeys.each {
            if (!langKeys.contains(it))
                println "$it in reference file does not exist in $lang"
        }
    })

    println "finished analyzing keys"
}
