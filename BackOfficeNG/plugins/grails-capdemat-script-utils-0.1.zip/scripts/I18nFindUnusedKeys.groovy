target ('default': "Find keys not referenced in any of views files") {
    findUnusedKeys()
}

target (findUnusedKeys: "Find keys not referenced in any of views files") {
    
    def printUsed = false
    def args = System.getProperty("grails.cli.args")
    if (args && args.trim().equals('verbose')) {
        printUsed = true
    }

    def referenceKeys = I18nSupport.extractKeys()

    referenceKeys.each { key ->
        boolean foundKey = false
        def keyFiles = []
        I18nSupport.forEachViewFile({ file ->
            if (file.getText().contains(key)) {
                keyFiles << file.absolutePath.substring(file.absolutePath.indexOf('BackOfficeNG') + 13)
                foundKey = true
            }
        })
        
        if (!foundKey)
            println "${key} does not seem to be used"
        else if (printUsed)
            println "found key ${key} in files ${keyFiles}"
    }
}
