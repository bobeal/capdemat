public class I18nSupport {
    
    //  add langs here
    def static langs = ['fr']
    def static baseFilename = 'grails-app/i18n/messages'
    def static extension = '.properties'
    def static viewDirs = ['modules']
    
    def static extractKeys = { lang ->
        def filename = baseFilename
        if (lang)
            filename += '_' + lang
        filename += extension
        def keys = []
        new File(filename).eachLine { line ->
            if (line.indexOf('=') != -1 && !line.startsWith('#')) {
                def key = line.substring(0,line.indexOf('=')).trim()
                keys << key
            }
        }
        return keys;
    }

    def static forEachLangFile(cl) {
        cl(new File(baseFilename + extension))
        langs.each { lang ->
            def langFile = new File(baseFilename + '_' + lang + extension)
            cl(langFile)
        }
    }
    
    def static eachKeysInLangFile(cl) {
        langs.each { lang ->
            def langKeys = I18nSupport.extractKeys(lang)
            cl(lang, langKeys)
        }
    }
    
    def static createBareKeysFile() {

        def referenceKeys = extractKeys(null)

        def bareKeysFile = new File('bare')
        bareKeysFile.delete()
        referenceKeys.each {
            bareKeysFile << it << '\n'
        }
    }
    
    def static forEachViewFile(cl) {
        viewDirs.each { dir ->
            new File(dir).eachFileRecurse { file ->
                if (file.getName().endsWith('.groovy') || file.getName().endsWith('.gsp')) {
                    cl(file)
                }
            }
        }
    }
}
