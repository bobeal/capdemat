import java.io.File;
import com.zenexity.capdemat.utils.*


class ModulesRouterGrailsPlugin {
    def version = 0.1
    def dependsOn = [:];
    def watchedResources = [
        "file:./modules/**/*Controller.groovy",
        "file:./modules/**/*.gsp"
    ];
    
    
    def onChange = { event ->
        def basedir = new File(event?.ctx.servletContext.getRealPath('.')).parent
        if(event?.source?.file) ModuleHelper.prepare(event.source.file,basedir)
    }
    
}
