import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU
import groovy.text.SimpleTemplateEngine

Ant.property(environment:"env")                             
grailsHome = Ant.antProject.properties."env.GRAILS_HOME"

includeTargets << new File ( "${grailsHome}/scripts/Clean.groovy" )

target ('default': "Cleans project modules") {
    cleanMod()
}

target (cleanMod: "Implementation of clean-mod") {
    event("CleanStart", [])
    println "# MODULES ROUTER CLEAN ALL #"
    
    def ant = new AntBuilder()
    File apps = new File("$basedir/modules")
    if(apps.exists()) {
        apps.eachFile {
            def app = it
            File cts = new File("${it.canonicalPath}/controllers")
            cts.eachFile {
                def cname = "${ModuleHelper.firstCase(app.name,'')}${it.name}"
                ant.delete(file:"$basedir/grails-app/controllers/$cname", failonerror:false)
                def vname = "$app.name${it.name.replaceAll('Controller.groovy','')}" 
                ant.delete(dir:"$basedir/grails-app/views/$vname")
            }
            
            ['shared','layouts'].each{
                def t = new File("$basedir/grails-app/views/$it")
                if(t.exists()) {
                    t.eachFile{
                        ant.delete(
                            file:"$basedir/grails-app/views/${t.name}/${it.name}", 
                            failonerror:false
                        )
                    }
                }
            }
            
            def mname = "${ModuleHelper.firstCase(app.name,'')}UrlMappings.groovy"
            ant.delete(file:"$basedir/grails-app/conf/$mname", failonerror:false)
        }
    }

    
    //depends(clean)
    event("CleanEnd", [])
}